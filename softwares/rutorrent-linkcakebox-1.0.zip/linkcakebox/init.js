/* URL de la Cakebox sur le serveur */
var url = '/cakebox/';

/* NE RIEN MODIFIER A PARTIR D'ICI
DO NOT MODIFY ANYTHING FROM HERE */
plugin.loadLang(true);
if (theWebUI.theme) {
  if (theWebUI.theme == 'Oblivion') {
    plugin.loadCSS("linkcakeboxoblivion");
  } else {
    plugin.loadCSS("linkcakebox");
  }
} else {
  plugin.loadCSS("linkcakebox");
}

// Ajout de l'icône dans le menu du haut
plugin.onLangLoaded = function()
{
  this.addButtonToToolbar("linkcakebox", theUILang.linkcakebox, "window.open('"+url+"')", "help");
  this.addSeparatorToToolbar("help");
}

// Ajout d'un lien dans le menu contextuel de chaque torrent
plugin.createMenu = theWebUI.createMenu;
theWebUI.createMenu = function(e, id)
{
	plugin.createMenu.call(this, e, id);
	if(plugin.enabled)
	{
              var cakeUrl = "'" + url + "watch.php?file=" + encodeURIComponent('downloads/' + theWebUI.torrents[id].name) +"'";
              theContextMenu.add(["Voir dans Cakebox","window.open(" + cakeUrl +")"]);
	}
	
}