theUILang.linkcakebox = "Streamer vos fichiers avec Cakebox";
